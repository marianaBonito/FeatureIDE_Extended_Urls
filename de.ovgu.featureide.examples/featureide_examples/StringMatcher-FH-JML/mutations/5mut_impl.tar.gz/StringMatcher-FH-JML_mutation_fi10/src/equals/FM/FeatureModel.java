package FM;

import gov.nasa.jpf.vm.Verify;

/**
 * Variability encoding of the feature model for JPF.
 * Auto-generated class.
 */
public class FeatureModel {

	public static Boolean equals_;
	public static Boolean prefix_a_b_;
	public static Boolean substring_a_b_;
	public static Boolean length_;
	public static Boolean prefix_b_a_;
	public static Boolean substring_b_a_;
	public static Boolean substring_;
	public static Boolean comparison_;
	public static Boolean stringmatcher_;

	/**
	 * Core features are set 'selected' and dead features 'unselected'.
	 * All other features have unknown selection states.
	 */
	static {
		comparison_ = true;
		stringmatcher_ = true;
	}

	/**
	 * This formula represents the validity of the current feature selection.
	 */
	public /*@pure@*/ static boolean valid() {
		Verify.resetCounter(0);
		boolean stringmatcher = true;
		boolean comparison = comparison_ != null ? comparison_ : true;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !((!stringmatcher  ||  comparison)  &&  (!comparison  ||  stringmatcher)));
		boolean length = length_ != null ? length_ : true ? random() : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !(!length  ||  comparison));
		boolean substring = substring_ != null ? substring_ : true ? length? false : random() : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !((!substring  ||  comparison)  &&  (!length  ||  !substring)));
		boolean equals = equals_ != null ? equals_ : true ? !(substring ||length) : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !((!comparison  ||  length  ||  substring  ||  equals)  &&  (!equals  ||  comparison)  &&  (!length  ||  !equals)  &&  (!substring  ||  !equals)));
		boolean substring_a_b = substring_a_b_ != null ? substring_a_b_ : substring ? random() : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !(!substring_a_b  ||  substring));
		boolean substring_b_a = substring_b_a_ != null ? substring_b_a_ : substring ? !(substring_a_b) : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !((!substring  ||  substring_a_b  ||  substring_b_a)  &&  (!substring_b_a  ||  substring)  &&  (!substring_a_b  ||  !substring_b_a)));
		boolean prefix_a_b = prefix_a_b_ != null ? prefix_a_b_ : substring_a_b ? random() : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !(!prefix_a_b  ||  substring_a_b));
		boolean prefix_b_a = prefix_b_a_ != null ? prefix_b_a_ : substring_b_a ? random() : false;
		Verify.ignoreIf(Verify.getCounter(0) != 0 || !(!prefix_b_a  ||  substring_b_a));
		Verify.incrementCounter(0);
		return true;
	}

	private static boolean random() {
		return Verify.getBoolean(false);
	}

	public static boolean stringmatcher() {
		if (stringmatcher_ == null) {
			stringmatcher_ = random();
			valid();
		}
		return stringmatcher_;
	}

	public static boolean comparison() {
		if (comparison_ == null) {
			comparison_ = random();
			valid();
		}
		return comparison_;
	}

	public static boolean length() {
		if (length_ == null) {
			length_ = random();
			valid();
		}
		return length_;
	}

	public static boolean substring_a_b() {
		if (substring_a_b_ == null) {
			substring_a_b_ = random();
			valid();
		}
		return substring_a_b_;
	}

	public static boolean prefix_a_b() {
		if (prefix_a_b_ == null) {
			prefix_a_b_ = random();
			valid();
		}
		return prefix_a_b_;
	}

	public static boolean substring_b_a() {
		if (substring_b_a_ == null) {
			substring_b_a_ = random();
			valid();
		}
		return substring_b_a_;
	}

	public static boolean prefix_b_a() {
		if (prefix_b_a_ == null) {
			prefix_b_a_ = random();
			valid();
		}
		return prefix_b_a_;
	}

	public static boolean equals() {
		if (equals_ == null) {
			equals_ = random();
			valid();
		}
		return equals_;
	}

	/**
	 * @return The current feature-selection.
	 */
	public static String getSelection(boolean names) {
		if (names) return  (stringmatcher_ != null && stringmatcher_ ? "StringMatcher\r\n" : "")  +  (comparison_ != null && comparison_ ? "Comparison\r\n" : "")  +  (length_ != null && length_ ? "Length\r\n" : "")  +  (substring_a_b_ != null && substring_a_b_ ? "Substring_a_b\r\n" : "")  +  (prefix_a_b_ != null && prefix_a_b_ ? "Prefix_a_b\r\n" : "")  +  (substring_b_a_ != null && substring_b_a_ ? "Substring_b_a\r\n" : "")  +  (prefix_b_a_ != null && prefix_b_a_ ? "Prefix_b_a\r\n" : "")  +  (equals_ != null && equals_ ? "Equals\r\n" : "") ;
		return stringmatcher_ + "|" + comparison_ + "|" + length_ + "|" + substring_a_b_ + "|" + prefix_a_b_ + "|" + substring_b_a_ + "|" + prefix_b_a_ + "|" + equals_;
	}

}